import junk, cache

print("Zantor, your macOS file manager.")

options = input("1. Junk File Cleaner\n2. Cache Cleaner\nChoose an option: ")
if options == '1':
    junk.junkfiletrigger()
elif options == '2':
    cache.cachecleanertrigger()