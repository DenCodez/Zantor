import junk, cache, time

print("Zantor, your macOS file manager.")
time.sleep(2)
print("Calling JUNK.PY and CACHE.PY, please wait...")
time.sleep(10)
options = input("1. Junk File Cleaner\n2. Cache Cleaner\nChoose an option: ")
if options == '1':
    junk.junkfiletrigger()
elif options == '2':
    cache.cachecleanertrigger()