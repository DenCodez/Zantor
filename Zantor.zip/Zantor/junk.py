import os


def junkfiletrigger():
    
    directory = input("Enter the directory to scan for junk files: ").strip()

    
    junk_extensions = ['.tmp', '.log', '.DS_Store', '.dylib', '.app', '.dmg', '.zip', '.pkg', '.jpg', '.png', 'mp4', '.mp3', '.gif', '.avif', '.jpeg', '.tiff', '.bmp', '.ico']

    junk_files = []

    for root, dirs, files in os.walk(directory):
        for file in files:
            if any(file.endswith(ext) for ext in junk_extensions):
                junk_files.append(os.path.join(root, file))

    
    if not junk_files:
        print("No junk files found.")
    else:
        print("Found junk files:")
        for idx, file in enumerate(junk_files, 1):
            print(f"{idx}. {file}")

        confirm = input("Do you want to delete these files? (y/n): ").strip().lower()
        if confirm == 'y':
            deleted = 0
            for file in junk_files:
                try:
                    os.remove(file)
                    deleted += 1
                except Exception as e:
                    print(f"Could not delete {file}: {e}")
            print(f"Deleted {deleted} files.")
        else:
            print("No files were deleted.")