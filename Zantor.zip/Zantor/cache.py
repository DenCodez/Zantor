import os
import shutil
from pathlib import Path

# Step 1: Define common cache directories on macOS
cache_dirs = [
    str(Path.home() / "Library" / "Caches"),
    "/Library/Caches",
    "/System/Library/Caches"
]

deleted_items = []

for cache_dir in cache_dirs:
    if os.path.exists(cache_dir):
        print(f"Cleaning: {cache_dir}")
        for item in os.listdir(cache_dir):
            item_path = os.path.join(cache_dir, item)
            try:
                if os.path.isdir(item_path):
                    shutil.rmtree(item_path)
                    deleted_items.append(item_path)
                else:
                    os.remove(item_path)
                    deleted_items.append(item_path)
            except Exception as e:
                print(f"Could not delete {item_path}: {e}")

print(f"\nDeleted {len(deleted_items)} items from cache directories.")